module com.example.amar {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.amar to javafx.fxml;
    exports com.example.amar;
}